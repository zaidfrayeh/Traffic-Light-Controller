#include <stdint.h>
#include "SysTick.h"
#include "msp432p401r.h"


struct State {
    uint32_t Out;
    uint32_t Outw;
    uint32_t Time; // 10 ms units
    const struct State *Next[20];
             };

typedef const struct State styp;

#define GOS     &FSM[0]
#define WAITS   &FSM[1]
#define GOW     &FSM[2]
#define WAITW   &FSM[3]
#define WALK    &FSM[4]
#define HON1    &FSM[5]
#define HOFF2   &FSM[6]
#define HON3    &FSM[7]
#define HOFF4   &FSM[8]
#define HON5    &FSM[9]
#define HOFF6   &FSM[10]
#define HON7    &FSM[11]
#define HOFF8   &FSM[12]
#define HON9    &FSM[13]
#define HON     &FSM[14]
#define HOFF    &FSM[15]
#define WAITWW  &FSM[16]
#define WAITWS  &FSM[17]
#define REQW    &FSM[18]
#define REQS    &FSM[19]

styp FSM[20] = {
 {0x21,0x01,100,{GOS,WAITS,GOS,WAITS,REQS,REQS,REQS,REQS}},        //1 gos
 {0x22,0x01,100,{GOW,GOW,GOW,GOW,REQS,REQS,REQS,REQS}},           //2 waitS
 {0x0C,0x01,100,{GOW,GOW,WAITW,WAITW,REQW,REQW,REQW,REQW}},        //3 goW
 {0x14,0x01,100,{GOS,GOS,GOS,GOS,REQW,REQW,REQW,REQW}},             //4 waitW
 {0x24,0x02,100,{WALK,HON1,HON1,HON1,WALK,HON1,HON1,HON1}},                 //WALK
 {0x24,0x01,100,{HOFF2,HOFF2,HOFF2,HOFF2,HOFF2,HOFF2,HOFF2,HOFF2}},    //HURRYON1
 {0x24,0x00,100,{HON3,HON3,HON3,HON3,HON3,HON3,HON3,HON3}},           //HURRYOFF2
 {0x24,0x01,100,{HOFF4,HOFF4,HOFF4,HOFF4,HOFF4,HOFF4,HOFF4,HOFF4}},   //HURRYON3
 {0x24,0x00,100,{HON5,HON5,HON5,HON5,HON5,HON5,HON5,HON5}},           //HURRYOFF4
 {0x24,0x01,50,{HOFF6,HOFF6,HOFF6,HOFF6,HOFF6,HOFF6,HOFF6,HOFF6}},   //HURRYON5
 {0x24,0x00,50,{HON7,HON7,HON7,HON7,HON7,HON7,HON7,HON7}},          //HURRYOFF6
 {0x24,0x01,50,{HOFF8,HOFF8,HOFF8,HOFF8,HOFF8,HOFF8,HOFF8,HOFF8}},  //HURRYON7
 {0x24,0x00,50,{HON9,HON9,HON9,HON9,HON9,HON9,HON9,HON9}},          //HURRYOFF8
 {0x24,0x01,50,{HOFF,HOFF,HOFF,HOFF,HOFF,HOFF,HOFF,HOFF}},           //HURRYON9
 {0x24,0x00,50,{HON,HON,HON,HON,HON,HON,HON,HON}},                  //HURRYON
 {0x24,0x01,100,{GOS,GOW,GOS,GOS,GOS,GOW,GOS,GOS}},                  //HURRYOFF
 {0x14,0x01,70,{GOS,GOW,GOS,GOS,WALK,WALK,WALK,WALK}},              //WAITWALKS
 {0x22,0x01,70,{GOS,GOW,GOS,GOW,WALK,WALK,WALK,WALK}},              //WAITWALKW
 {0x0C,0x01,70,{GOS,GOW,GOS,GOS,WAITWW,WAITWW,WAITWW,WAITWW}},     //REQW
 {0x21,0x01,70,{GOS,GOS,GOS,GOW,WAITWS,WAITWS,WAITWS,WAITWS}}             //REQS
             };

void ports(void){

   //output pins
        P4SEL0 &= ~0x3F;
        P4SEL1 &= ~0x3F;
        P4DIR  |= 0x3F;

   // output led
        P2SEL0 &= ~0x03;
        P2SEL1 &= ~0x03;
        P2DS   |= 0x03;
        P2DIR  |= 0x03;
        P2OUT  |= 0x03;

   //input buttons
        P1SEL0 = 0x00;
        P1SEL1 = 0x00;
        P1DS   = 0x00;
        P1DIR  = 0x00;
        P1REN  = 0X02;
        P1OUT  = 0x02;


   //input buttons
        P5SEL0 &= ~0x06;
        P5SEL1 &= ~0x06;
        P5DIR  &= ~0x06;
}
void main(void){

    uint32_t Input;
    uint32_t Input2;


    styp *Pt;

   SysTick_Init();
   ports();

    // start state
    Pt = GOS;
while(1){
            P4OUT=(Pt -> Out);
            P2OUT=((Pt -> Outw)&0x03);

            SysTick_Wait10ms(Pt->Time);

            Input = P5IN&06;
            Input = Input/2;

            Input2 = ((~P1IN&0x02) <<1 );

            Pt = Pt->Next[Input2 + Input];
         }
              }
